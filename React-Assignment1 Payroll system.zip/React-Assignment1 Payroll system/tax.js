

export default function calculateTax(salary) {
  return salary * 0.2; // 20% tax
}