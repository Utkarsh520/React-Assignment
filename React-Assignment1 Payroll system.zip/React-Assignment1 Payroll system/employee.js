

export function getEmployeeDetails(id) {
  return {
    id: id,
    name: "Utkarsh",
    salary: 50000
  };
}