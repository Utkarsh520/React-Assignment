

import calculateTax from "./tax.js";  // default import
import { getEmployeeDetails } from "./employee.js"; // named import

const employee = getEmployeeDetails(101);

const tax = calculateTax(employee.salary);

console.log("Employee Details:", employee);
console.log("Calculated Tax:", tax);